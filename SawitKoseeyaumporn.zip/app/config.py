from pathlib import Path

DATA_DIR = Path("data")
REDIS_HOST = "redis"
REDIS_PORT = 6379

EARTH_RADIUS_METERS = 6_371_000
